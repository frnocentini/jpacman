package sprites;

public enum State {
    CHASE,SCATTER,FRIGHTENED,EATEN;
}
