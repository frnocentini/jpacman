1. Assicurarsi di aver installato una JRE compatibile con software Java compilato con JDK 11
2. Cliccare su StartGame.bat o, alternativamente, aprire la directory con il terminale e
digitare "java -jar JPacman.jar"